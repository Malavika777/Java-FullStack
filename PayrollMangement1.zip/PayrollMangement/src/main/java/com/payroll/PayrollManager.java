package com.payroll;

import java.sql.*;

public class PayrollManager {
    public void processSalary(int empId) {
        String query = "SELECT salary FROM employee WHERE id=?";
        String insertQuery = "INSERT INTO payroll (emp_id, base_salary, deductions, net_salary, pay_date) VALUES (?, ?, ?, ?, CURDATE())";
        String updateEmployeeSalary = "UPDATE employee SET salary = ? WHERE id = ?"; // 🔹 Update salary in employee table

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
             PreparedStatement updateStmt = conn.prepareStatement(updateEmployeeSalary)) {

            stmt.setInt(1, empId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                double baseSalary = rs.getDouble("salary");
                double deductions = calculateDeductions(baseSalary);
                double netSalary = baseSalary - deductions;

                // Insert into payroll table
                insertStmt.setInt(1, empId);
                insertStmt.setDouble(2, baseSalary);
                insertStmt.setDouble(3, deductions);
                insertStmt.setDouble(4, netSalary);
                insertStmt.executeUpdate();

                //  Update employee's salary
                updateStmt.setDouble(1, netSalary);
                updateStmt.setInt(2, empId);
                updateStmt.executeUpdate();

                System.out.println("Salary processed successfully for Employee ID " + empId);
                System.out.println("Base Salary: $" + baseSalary);
                System.out.println("Deductions: $" + deductions);
                System.out.println("Net Salary: $" + netSalary);
                System.out.println("Updated Salary in Employee Table: $" + netSalary);
            } else {
                System.out.println("Employee not found!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private double calculateDeductions(double salary) {
        // deduction calculation: 10% tax + 5% provident fund
        double tax = salary * 0.10;
        double providentFund = salary * 0.05;
        return tax + providentFund;
    }
}