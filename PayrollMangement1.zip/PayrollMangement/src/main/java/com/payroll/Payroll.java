package com.payroll;

public class Payroll {
    private int payId;
    private int empId;
    private double baseSalary;
    private double deductions;
    private double netSalary;
    private String payDate;

    public Payroll(int payId, int empId, double baseSalary, double deductions, double netSalary, String payDate) {
        this.payId = payId;
        this.empId = empId;
        this.baseSalary = baseSalary;
        this.deductions = deductions;
        this.netSalary = netSalary;
        this.payDate = payDate;
    }

    @Override
    public String toString() {
        return "Pay ID: " + payId + ", Employee ID: " + empId +
                ", Base Salary: " + baseSalary + ", Deductions: " + deductions +
                ", Net Salary: " + netSalary + ", Pay Date: " + payDate;
    }
}
