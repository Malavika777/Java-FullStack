package com.payroll;

import java.sql.*;

public class EmployeeManager {
    public void addEmployee(String name, String department, String position, double salary) {
        String query = "INSERT INTO employee (name, department, position, salary) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, department);
            stmt.setString(3, position);
            stmt.setDouble(4, salary);
            stmt.executeUpdate();
            System.out.println("Employee added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateEmployee(int id, String newDept, String newPos, double newSalary) {
        String query = "UPDATE employee SET department=?, position=?, salary=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, newDept);
            stmt.setString(2, newPos);
            stmt.setDouble(3, newSalary);
            stmt.setInt(4, id);
            int updated = stmt.executeUpdate();
            if (updated > 0)
                System.out.println("Employee updated successfully!");
            else
                System.out.println("Employee not found!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteEmployee(int id) {
        String query = "DELETE FROM employee WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            int deleted = stmt.executeUpdate();
            if (deleted > 0)
                System.out.println("Employee deleted successfully!");
            else
                System.out.println("Employee not found!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewEmployees() {
        String query = "SELECT * FROM employee";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            System.out.println("\nEmployee List:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                                   rs.getString("name") + " | " +
                                   rs.getString("department") + " | " +
                                   rs.getString("position") + " | " +
                                   rs.getDouble("salary"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
