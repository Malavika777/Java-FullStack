package com.payroll;

import java.util.Scanner;

public class PayrollSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmployeeManager empManager = new EmployeeManager();
        PayrollManager payrollManager = new PayrollManager();

        while (true) {
            System.out.println("\n1. Add Employee\n2. Update Employee\n3. Delete Employee\n4. View Employees\n5. Process Salary\n6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    scanner.nextLine();  // Consume newline
                    String name = scanner.nextLine();
                    System.out.print("Department: ");
                    String dept = scanner.nextLine();
                    System.out.print("Position: ");
                    String pos = scanner.nextLine();
                    System.out.print("Salary: ");
                    double salary = scanner.nextDouble();
                    empManager.addEmployee(name, dept, pos, salary);
                    break;

                case 2:
                    System.out.print("Employee ID: ");
                    int id = scanner.nextInt();
                    System.out.print("New Department: ");
                    scanner.nextLine();  // Consume newline
                    String newDept = scanner.nextLine();
                    System.out.print("New Position: ");
                    String newPos = scanner.nextLine();
                    System.out.print("New Salary: ");
                    double newSalary = scanner.nextDouble();
                    empManager.updateEmployee(id, newDept, newPos, newSalary);
                    break;

                case 3:
                    System.out.print("Enter Employee ID to Delete: ");
                    int delId = scanner.nextInt();
                    empManager.deleteEmployee(delId);
                    break;

                case 4:
                    empManager.viewEmployees();
                    break;

                case 5:
                    System.out.print("Employee ID: ");
                    int empId = scanner.nextInt();
                    payrollManager.processSalary(empId); // Automatically calculates deductions
                    break;

                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}