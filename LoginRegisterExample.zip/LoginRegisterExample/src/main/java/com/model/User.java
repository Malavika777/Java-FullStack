package com.model;
import java.util.Date;
public class User {
	int slno;
	String fullname,uname,password,gender,qualification,status;
	Date dob;
	public User(String fullname, String uname, String password, String gender, String qualification, String status,
			Date dob) {
		super();
		this.fullname = fullname;
		this.uname = uname;
		this.password = password;
		this.gender = gender;
		this.qualification = qualification;
		this.status = status;
		this.dob = dob;
	}
	public int getSlno() {
		return slno;
	}
	public void setSlno(int slno) {
		this.slno = slno;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}

}
