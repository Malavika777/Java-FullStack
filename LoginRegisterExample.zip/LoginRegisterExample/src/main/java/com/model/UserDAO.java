package com.model;

import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String fname="";
	public UserDAO() {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/payrolldb","root","Malu@2005");
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException s) {
			s.printStackTrace();
		}
	}
	public String checkUser(String u,String p) {
		String sql="select fullname from userdata where uname=? and password=?";
		try {
		pst=con.prepareStatement(sql);
	
		pst.setString(1, u);
		pst.setString(2, p);
		rs=pst.executeQuery();
		if(rs.next()) {
			fname=rs.getString(1);
		}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return fname;
	}
	public void saveUser(User user) {
		String sql="insert into userdata(fullname, uname, password, qualification, gender, dob, status) values(?, ?, ?, ?, ?, ?, ?)";
		try {
			pst=con.prepareStatement(sql);
			pst.setString(1,user.getFullname());
			pst.setString(2, user.getUname());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getQualification());
			pst.setString(5, user.getGender());
			pst.setDate(6, new Date(user.getDob().getTime()));
			pst.setString(7, user.getStatus());
			
			int result=pst.executeUpdate();
			if(result>0) {
				System.out.println("Data Stored Successfully");
			}
		}
		catch(SQLException s) {
			s.printStackTrace();
		}
	}
	public ResultSet listUser() {
		return rs;
	}
}
