package com.controller;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.model.User;
import com.model.UserDAO;

@WebServlet("/RegisterCont")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("fname");
		String uname=request.getParameter("uname");
		String passowrd=request.getParameter("pass");
		String rpassword=request.getParameter("rpass");
		String qualification=request.getParameter("qualification");
		String gender=request.getParameter("gender");
		String d=request.getParameter("dob");
		System.out.println(d);
		String status=request.getParameter("status");
		Date dob=null;
		SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
		try {
			dob=sd.parse(d);
			System.out.println(dob);
		}
		catch(ParseException e) {
			e.printStackTrace();
		}
		User user=new User(fname,uname,rpassword,qualification,gender,status,dob);
		UserDAO ud=new UserDAO();
		ud.saveUser(user);
		HttpSession session=request.getSession();
		session.setAttribute("fname",fname );
		request.getRequestDispatcher("DashboardServ").forward(request,response);
		
	}

}
