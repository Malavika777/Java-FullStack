//package com.controller;
//
//import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpSession;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.model.UserDAO;
//
///**
// * Servlet implementation class LoginController
// */
//@WebServlet("/LoginCont")
//public class LoginController extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		String uname=request.getParameter("uname");
//		String password=request.getParameter("pass");
//		List<String> errors=new ArrayList<>();
//		if(uname.length()==0)
//			errors.add("Enter Username");
//		if(password.length()==0)
//			errors.add("Enter Password");
//		
//		String fname=new UserDAO().checkUser(uname,password);
//		if(fname==null) {
//			errors.add("incorrect Username or Password");
//			request.getRequestDispatcher("Login.jsp").forward(request, response);
//		}
//		if(!errors.isEmpty()) {
//			request.setAttribute("errors", errors);
//			request.getRequestDispatcher("Login.jsp").forward(request, response);
//		}
//			HttpSession session=request.getSession();
//			session.setAttribute("fname",fname );
//			request.getRequestDispatcher("dashboard.jsp").forward(request,response);
//			return;
//	}
//
//}
package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.model.UserDAO;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginCont")
public class LoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uname = request.getParameter("uname");
        String password = request.getParameter("pass");
        List<String> errors = new ArrayList<>();

        // Check if username or password fields are empty
        if (uname == null || uname.isEmpty()) {
            errors.add("Enter Username");
        }
        if (password == null || password.isEmpty()) {
            errors.add("Enter Password");
        }

        // If there are any input errors, return to login page
        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.getRequestDispatcher("Login.jsp").forward(request, response);
            return;
        }

        // Validate user credentials
        String fname = new UserDAO().checkUser(uname, password);

        if (fname == null||fname.isEmpty()) {
            // User not found: Redirect to register page
     
        	request.getRequestDispatcher("Registerhtml.jsp").forward(request, response);
        }

        // If login is successful, create session and redirect to dashboard
        else {
        HttpSession session = request.getSession();
        session.setAttribute("fname", fname);
        response.sendRedirect("dashboard.jsp");
        }
    }
}
